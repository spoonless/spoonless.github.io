package io.github.spoonless;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean
@RequestScoped
public class MonControleur {

	private String resultat;

	public String getResultat() {
		return resultat;
	}

	public void traiter() {
		resultat = "Bravo, vous avez fait une requête Ajax !";
	}

}
