Le fichier qrcode.png encode l'adresse demo://test

Avec un scanner de QRCode, vous pouvez l'utiliser pour ouvrir une activité de cette application.
